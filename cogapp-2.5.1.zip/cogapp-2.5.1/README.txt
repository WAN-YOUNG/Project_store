Cog code generation tool.

See http://nedbatchelder.com/code/cog for details.

To run the tests::

    $ pip install tox
    $ tox

(Sometimes tox fails on new installations. Run tox again, it will be fine.)
